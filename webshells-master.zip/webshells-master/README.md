Various webshells. Please send add more via pull requests. :)
