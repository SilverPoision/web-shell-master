User-agent: *
Allow: /#Begin Attracta SEO Tools Sitemap. Do not remove
sitemap: http://cdn.attracta.com/sitemap/2519186.xml.gz
#End Attracta SEO Tools Sitemap. Do not remove
