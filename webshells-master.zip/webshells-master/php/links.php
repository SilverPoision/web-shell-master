<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma;
	font-size: 12px;
	color: #636161;
}
body {
	margin-top: 100px;
	margin-left: 200px;
	margin-right: 200px;
	background-color: #0D0C0C;
}
a {
	font-size: 12px;
}
a:link {
	text-decoration: none;
	color: #666666;
}
a:visited {
	text-decoration: none;
	color: #666666;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-style: italic;
}
-->
</style><title>r57.txt - c99.txt - r57 shell - c99 shell - r57shell - c99shell - r57 -
c99 - shell archive - php shells - php exploits - bypass shell - safe mode
bypass - sosyete safe mode bypass shell - Evil Shells - exploit - root -
r57.in</title>
<meta name="title" content="r57.txt - c99.txt - r57 shell - c99 shell - r57shell - c99shell - r57 - c99 - shell archive - php shells - php exploits - bypass shell - safe mode bypass - sosyete safe mode bypass shell - Evil Shells - exploit - root - r57.in" />
<meta name="description" content="r57.txt - c99.txt - r57 shell - c99 shell - r57shell - c99shell - r57 -
c99 - shell archive - php shells - php exploits - bypass shell - safe mode
bypass - sosyete safe mode bypass shell - Evil Shells - exploit - root -
r57.in" />
<meta name="keywords" content="r57.txt - c99.txt - r57 shell - c99 shell - r57shell - c99shell - r57 - c99 - shell archive - php shells - php exploits - bypass shell - safe mode bypass - sosyete safe mode bypass shell - Evil Shells - exploit - root - r57.in" />
<meta name="author" content="r57.in" />
<meta name="owner" content="Herkes" />
<meta name="copyright" content="(c) 2009" />

<div align="center">
  <pre>

<TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="80%" bgColor=#333333 borderColorLight=#c0c0c0 border=1><tr>
    <p align="center">
<img src="http://localshell.net/banner.jpg" alt="ShellCodes and Exploits City" width="587" height="71"></table>
<TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1><tr>
    <p align="center"><a href="index.php">[  Home  ]</a>    |    <a href="shell.php">[  Shell  ]</a>   |    <a href="video.php">[  Video  ]</a>   |  <a href="links.php">[  Links  ]</a>  

</table>
<TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1><tr>
    <p align="center">
<a href="http://tr0yan0.blogspot.com">[ Sosyete</a>   |   <a href="http://t0fan.blogspot.com">T0fan</a> 
<a href="http://kernel.sh">[ Kernel@Sh</a>   |   <a href="http://milw0rm.com">Milw0rm</a>
<a href="http://www.googlebig.com/">Google Big</a>   <a href="http://www.darkc0de.com/">Darkc0de</a> ] <a href="http://www.remote-exploit.org">BackTrack ]</a>




www.r57.in
</table>

Send all submissions to  Mail <a href="mailto:thesabotaqe@gmail.com">r57</a> or r57.in 

 Copyright � 2oo8~2oo9 <a href="http://localshell.net">Localshell</a>

Sitemiz en iyi Firefox ile (1024 x 768 veya �st� ��z�n�rl�kte) g�r�nmektedir. 
</table>
</pre>
</div>
